# ml_starterapp
This project contains the starter for the machine learning project to predict the Price of House in Banglore City.
